"""
Tech Arena 2025 - Phase 2 Inference Pipeline
Entry point for evaluation system
"""

from .pipeline import loadPipeline

__all__ = ['loadPipeline']
